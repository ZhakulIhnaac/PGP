<?php 
include '../../url_degiskenleri/url_degiskenleri.php' ;   
?> 

<html>


    
<head>
<link rel="stylesheet" type="text/css" href="<?=$css_dosyasi?>">
</head>
  
<?php include "$header";    ?>
    
ANA SAYFAYA HOŞ GELDİNİZ.

<!-- burayı zaten menü kısmına, headera koyduğumuz için şimdilik kaldırıyoruz    
<nav>
      <ul>
        <li><a href="../../ekran0/ver001/ekran0.php">Ana Sayfa</a></li>
        <li><a href="../../ekran1/ver007/ekran1.php">Ekran1 - Müşteri Ekle</a></li>
        <li><a href="../../ekran3/ver002/ekran3.php" class="active">Ekran3 - Müşterileri Listele</a></li>
      </ul>
</nav>

--> 

<?php
include "$footer";
?>
    
</html>    