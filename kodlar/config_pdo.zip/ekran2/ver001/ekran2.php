<html>
ekran2
<br>
Burada Müşteriler Listelenecek
<?php

include '../../config_pdo/ver002/config.php';
include '../../url_degiskenleri/url_degiskenleri.php' ;

$musteri_adi = $_GET['musteri_adi'];



?>

</html>