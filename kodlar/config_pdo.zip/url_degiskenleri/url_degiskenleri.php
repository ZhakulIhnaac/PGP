<?php

$config= "../../config_pdo/ver002/config.php" ; 
$ekran0 = "../../ekran0/ver001/ekran0.php";
$ekran1= "../../ekran1/ver011/ekran1.php";
$ekran2= "../../ekran2/ver003/ekran2.php";
$ekran3= "../../ekran3/ver006/ekran3.php";
$ekran4= "../../ekran4/ver003/ekran4.php";
$ekran5= "../../ekran5/ver001/ekran5.php";
$footer = "../../footer/ver001/footer.php";
$css_dosyasi = "../../css_dosyasi/ver003/css_dosyasi.css";
$header = "../../header/ver001/header.php";
$getxmlhttp = "../../getxmlhttp/ver002/getxmlhttp.js";
$usecase = "../../../diyagramlar/usecase/usecase.JPG";
$flowchart ="../../../diyagramlar/flowchart/flowchart.JPG";
?>