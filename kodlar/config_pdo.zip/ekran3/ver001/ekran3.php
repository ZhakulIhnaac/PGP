<html>

ekran3
    
<?php 

include '../../url_degiskenleri/url_degiskenleri.php';
include "$config";    

?>
<br>    
<a href=<?="$ekran1"?>>Müşteri Ekle</a>    
    
    
</html>