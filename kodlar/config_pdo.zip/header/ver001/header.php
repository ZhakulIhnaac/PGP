<html>

<div id="ust"> PHP GELİŞTİRME MENÜLERİ </div>    

<table>
<tr>
<td>
<a href="<?=$ekran0?>"> Ekran0- Ana Sayfa </a>    
</td>
<td>
<a href="<?=$ekran1?>"> Ekran1- Müşteri Ekle </a>    
</td>    
<td>
<a href="<?=$ekran3?>"> Ekran3- Müşteri Listele </a>    
</td>   
<td>
<a href="<?=$usecase?>"> Usecase Diyagramı </a>    
</td>   
<td>
<a href="<?=$flowchart?>"> Flowchart </a>    
</td>    
</tr>
</table>    
    
    
</html>